import React from 'react';
import { Github, Linkedin, Mail, Phone, Youtube, Server, Cloud, Cog } from 'lucide-react';

const Sidebar: React.FC = () => {
  return (
    <div className="w-80 p-8 backdrop-blur-md bg-white/5 border-r border-white/10">
      {/* Logo */}
      <div className="mb-12">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Server className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Kiran Garud</h2>
            <p className="text-sm text-gray-300">DevOps Engineer</p>
          </div>
        </div>
      </div>

      {/* Get in Touch */}
      <div className="mb-12">
        <h3 className="text-lg font-semibold mb-6 text-blue-300">Get in Touch</h3>
        <div className="space-y-4">
          <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors">
            <Mail className="w-5 h-5" />
            <span className="text-sm">kiran.garud@email.com</span>
          </div>
          <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors">
            <Phone className="w-5 h-5" />
            <span className="text-sm">+1 (555) 123-4567</span>
          </div>
        </div>
      </div>

      {/* Social Links */}
      <div className="mb-12">
        <h3 className="text-lg font-semibold mb-6 text-blue-300">Connect</h3>
        <div className="flex space-x-4">
          <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
            <Linkedin className="w-5 h-5" />
          </a>
          <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
            <Github className="w-5 h-5" />
          </a>
          <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
            <Youtube className="w-5 h-5" />
          </a>
        </div>
      </div>

      {/* Skills Quick View */}
      <div>
        <h3 className="text-lg font-semibold mb-6 text-blue-300">Core Skills</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Cloud className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-gray-300">AWS Solutions Architecture</span>
          </div>
          <div className="flex items-center space-x-2">
            <Server className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-gray-300">Kubernetes & Docker</span>
          </div>
          <div className="flex items-center space-x-2">
            <Cog className="w-4 h-4 text-indigo-400" />
            <span className="text-sm text-gray-300">CI/CD Automation</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;