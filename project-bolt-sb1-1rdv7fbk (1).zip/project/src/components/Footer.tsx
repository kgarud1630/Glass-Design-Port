import React from 'react';
import { Heart, Code, Coffee } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/20 backdrop-blur-sm border-t border-white/10 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* About */}
          <div>
            <h4 className="text-lg font-semibold text-blue-300 mb-4">Kiran Garud</h4>
            <p className="text-gray-400 text-sm leading-relaxed">
              DevOps Engineer passionate about cloud infrastructure, automation, and building scalable solutions.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-blue-300 mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Projects</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Services</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Blog</a></li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold text-blue-300 mb-4">Services</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cloud Migration</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">DevOps Consulting</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Infrastructure Setup</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">CI/CD Implementation</a></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold text-blue-300 mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-400">kiran.garud@email.com</li>
              <li className="text-gray-400">+1 (555) 123-4567</li>
              <li className="text-gray-400">San Francisco, CA</li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-2 text-gray-400 text-sm mb-4 md:mb-0">
            <span>&copy; 2025 Kiran Garud. All rights reserved.</span>
          </div>
          
          <div className="flex items-center space-x-2 text-gray-400 text-sm">
            <span>Built with</span>
            <Heart className="w-4 h-4 text-red-400" />
            <span>using</span>
            <Code className="w-4 h-4 text-blue-400" />
            <span>React & Tailwind CSS</span>
            <Coffee className="w-4 h-4 text-yellow-400" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;