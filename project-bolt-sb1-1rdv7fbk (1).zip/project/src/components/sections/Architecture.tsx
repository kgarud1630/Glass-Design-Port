import React from 'react';
import { Network, Database, Shield, Zap, Cloud, Server, GitBranch, Monitor } from 'lucide-react';

const Architecture: React.FC = () => {
  const architectures = [
    {
      title: 'Microservices on Kubernetes',
      description: 'Scalable microservices architecture with service mesh, auto-scaling, and observability.',
      components: ['API Gateway', 'Service Mesh', 'Container Registry', 'Monitoring Stack'],
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Kubernetes', 'Istio', 'Prometheus', 'Grafana']
    },
    {
      title: 'Serverless Event-Driven Architecture',
      description: 'Cost-effective serverless solution with event-driven processing and auto-scaling.',
      components: ['Lambda Functions', 'Event Bridge', 'DynamoDB', 'API Gateway'],
      image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['AWS Lambda', 'EventBridge', 'DynamoDB', 'CloudWatch']
    },
    {
      title: 'Multi-Cloud Hybrid Infrastructure',
      description: 'Resilient multi-cloud setup with disaster recovery and seamless failover capabilities.',
      components: ['Load Balancers', 'Cross-Cloud VPN', 'Data Replication', 'Monitoring'],
      image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['AWS', 'Azure', 'Terraform', 'Consul']
    }
  ];

  const designPrinciples = [
    {
      icon: Shield,
      title: 'Security First',
      description: 'Zero-trust architecture with end-to-end encryption and comprehensive access controls.'
    },
    {
      icon: Zap,
      title: 'High Performance',
      description: 'Optimized for speed with caching layers, CDNs, and efficient resource utilization.'
    },
    {
      icon: Network,
      title: 'Scalability',
      description: 'Auto-scaling capabilities that adapt to demand with horizontal and vertical scaling.'
    },
    {
      icon: Monitor,
      title: 'Observability',
      description: 'Comprehensive monitoring, logging, and tracing for complete system visibility.'
    }
  ];

  const infrastructureComponents = [
    {
      category: 'Compute',
      icon: Server,
      items: ['Kubernetes Clusters', 'Auto Scaling Groups', 'Serverless Functions', 'Container Instances']
    },
    {
      category: 'Storage',
      icon: Database,
      items: ['Object Storage', 'Block Storage', 'Database Clusters', 'Backup Solutions']
    },
    {
      category: 'Networking',
      icon: Network,
      items: ['Load Balancers', 'CDN', 'VPC/VNet', 'Service Mesh']
    },
    {
      category: 'DevOps',
      icon: GitBranch,
      items: ['CI/CD Pipelines', 'GitOps', 'Infrastructure as Code', 'Artifact Registry']
    }
  ];

  return (
    <div className="flex-1 p-8 space-y-12">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          Architecture & Design
        </h2>
        
        {/* Featured Architectures */}
        <div className="space-y-8 mb-16">
          <h3 className="text-2xl font-semibold text-blue-300 mb-6">Featured Architecture Patterns</h3>
          {architectures.map((arch, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
                <div className="p-8">
                  <h4 className="text-2xl font-bold text-white mb-4">{arch.title}</h4>
                  <p className="text-gray-300 mb-6 leading-relaxed">{arch.description}</p>
                  
                  <div className="mb-6">
                    <h5 className="text-lg font-semibold text-blue-300 mb-3">Key Components:</h5>
                    <div className="grid grid-cols-2 gap-2">
                      {arch.components.map((component, i) => (
                        <div key={i} className="flex items-center space-x-2 text-sm text-gray-300">
                          <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                          <span>{component}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h5 className="text-lg font-semibold text-blue-300 mb-3">Technologies:</h5>
                    <div className="flex flex-wrap gap-2">
                      {arch.tech.map((tech, i) => (
                        <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
                    View Detailed Diagram
                  </button>
                </div>
                
                <div className="relative h-64 lg:h-auto">
                  <img 
                    src={arch.image} 
                    alt={arch.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-600/20"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Design Principles */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-blue-300 mb-8">Design Principles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {designPrinciples.map((principle, index) => {
              const IconComponent = principle.icon;
              return (
                <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500/20 to-purple-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-blue-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-3">{principle.title}</h4>
                  <p className="text-gray-300 text-sm leading-relaxed">{principle.description}</p>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Infrastructure Components */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-blue-300 mb-8">Infrastructure Components</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {infrastructureComponents.map((component, index) => {
              const IconComponent = component.icon;
              return (
                <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500/20 to-purple-600/20 rounded-lg flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-blue-400" />
                    </div>
                    <h4 className="text-lg font-semibold text-white">{component.category}</h4>
                  </div>
                  <ul className="space-y-2">
                    {component.items.map((item, i) => (
                      <li key={i} className="flex items-center space-x-2 text-sm text-gray-300">
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Architecture Consultation CTA */}
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 backdrop-blur-md border border-white/20 rounded-2xl p-8 text-center">
          <Cloud className="w-16 h-16 text-blue-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-4">Need Custom Architecture Design?</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Let's collaborate to design the perfect architecture for your specific requirements, 
            ensuring scalability, security, and cost-effectiveness.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
              Schedule Architecture Review
            </button>
            <button className="px-8 py-3 bg-white/10 border border-white/20 rounded-lg font-medium hover:bg-white/20 transition-all">
              Download Architecture Guide
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Architecture;