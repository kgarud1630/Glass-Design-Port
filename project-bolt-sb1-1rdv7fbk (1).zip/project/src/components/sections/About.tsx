import React from 'react';
import { User, MapPin, Calendar, Award, Target, Heart } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          About Me
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Personal Info */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <User className="w-6 h-6 text-blue-400" />
              <h3 className="text-xl font-semibold">Personal Information</h3>
            </div>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">San Francisco, CA</span>
              </div>
              <div className="flex items-center space-x-3">
                <Calendar className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">5+ Years Experience</span>
              </div>
              <div className="flex items-center space-x-3">
                <Award className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">AWS Certified Solutions Architect</span>
              </div>
            </div>
          </div>

          {/* Mission */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <Target className="w-6 h-6 text-purple-400" />
              <h3 className="text-xl font-semibold">Mission</h3>
            </div>
            <p className="text-gray-300 leading-relaxed">
              To bridge the gap between development and operations by creating robust, 
              scalable infrastructure solutions that enable teams to deliver software 
              faster and more reliably.
            </p>
          </div>
        </div>

        {/* Bio */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mt-8">
          <div className="flex items-center space-x-3 mb-6">
            <Heart className="w-6 h-6 text-red-400" />
            <h3 className="text-2xl font-semibold">My Story</h3>
          </div>
          <div className="space-y-4 text-gray-300 leading-relaxed">
            <p>
              I'm a passionate DevOps Engineer with over 5 years of experience in cloud infrastructure, 
              automation, and continuous integration/deployment. My journey began as a system administrator, 
              where I discovered my love for optimizing processes and solving complex technical challenges.
            </p>
            <p>
              Throughout my career, I've had the privilege of working with diverse teams and technologies, 
              from startups to enterprise-level organizations. I specialize in AWS cloud services, 
              containerization with Docker and Kubernetes, and building robust CI/CD pipelines that 
              enable teams to deploy with confidence.
            </p>
            <p>
              When I'm not architecting cloud solutions, you'll find me contributing to open-source projects, 
              writing technical blogs, or mentoring aspiring DevOps engineers. I believe in the power of 
              automation to transform how we build and deploy software, and I'm always excited to tackle 
              new challenges that push the boundaries of what's possible.
            </p>
          </div>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-6 h-6 text-blue-400" />
            </div>
            <h4 className="text-lg font-semibold mb-2">Innovation</h4>
            <p className="text-sm text-gray-400">Always exploring new technologies and methodologies to improve efficiency</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-6 h-6 text-purple-400" />
            </div>
            <h4 className="text-lg font-semibold mb-2">Excellence</h4>
            <p className="text-sm text-gray-400">Committed to delivering high-quality solutions that exceed expectations</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-6 h-6 text-green-400" />
            </div>
            <h4 className="text-lg font-semibold mb-2">Collaboration</h4>
            <p className="text-sm text-gray-400">Building strong partnerships between development and operations teams</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;