import React from 'react';
import { Calendar, Clock, Eye, Heart, MessageCircle, ArrowRight, Tag } from 'lucide-react';

const Blog: React.FC = () => {
  const featuredPost = {
    title: 'Building Resilient Microservices with Kubernetes and Service Mesh',
    excerpt: 'A comprehensive guide to implementing fault-tolerant microservices architecture using Kubernetes, Istio, and modern DevOps practices.',
    image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
    date: '2024-01-15',
    readTime: '12 min read',
    views: '2.5K',
    likes: 156,
    comments: 23,
    tags: ['Kubernetes', 'Microservices', 'DevOps', 'Architecture']
  };

  const blogPosts = [
    {
      title: 'Automating AWS Infrastructure with Terraform and GitOps',
      excerpt: 'Learn how to implement Infrastructure as Code using Terraform with GitOps workflows for automated, reliable deployments.',
      image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-10',
      readTime: '8 min read',
      views: '1.8K',
      likes: 89,
      comments: 15,
      tags: ['AWS', 'Terraform', 'GitOps']
    },
    {
      title: 'Container Security Best Practices for Production',
      excerpt: 'Essential security practices for containerized applications, from image scanning to runtime protection.',
      image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-05',
      readTime: '10 min read',
      views: '2.1K',
      likes: 134,
      comments: 28,
      tags: ['Security', 'Docker', 'Kubernetes']
    },
    {
      title: 'Monitoring and Observability in Cloud-Native Applications',
      excerpt: 'Implementing comprehensive monitoring solutions with Prometheus, Grafana, and distributed tracing.',
      image: 'https://images.pexels.com/photos/1181678/pexels-photo-1181678.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2023-12-28',
      readTime: '15 min read',
      views: '3.2K',
      likes: 201,
      comments: 42,
      tags: ['Monitoring', 'Observability', 'Cloud-Native']
    },
    {
      title: 'CI/CD Pipeline Optimization: From Hours to Minutes',
      excerpt: 'Strategies and techniques to dramatically reduce build and deployment times in your CI/CD pipelines.',
      image: 'https://images.pexels.com/photos/1181679/pexels-photo-1181679.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2023-12-20',
      readTime: '7 min read',
      views: '1.5K',
      likes: 76,
      comments: 12,
      tags: ['CI/CD', 'Performance', 'Automation']
    },
    {
      title: 'Multi-Cloud Strategy: Benefits, Challenges, and Implementation',
      excerpt: 'A deep dive into multi-cloud architectures, when to use them, and how to implement them effectively.',
      image: 'https://images.pexels.com/photos/1181680/pexels-photo-1181680.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2023-12-15',
      readTime: '11 min read',
      views: '2.7K',
      likes: 167,
      comments: 35,
      tags: ['Multi-Cloud', 'Strategy', 'Architecture']
    },
    {
      title: 'Serverless vs Containers: Choosing the Right Architecture',
      excerpt: 'Comparing serverless and containerized architectures to help you make the right choice for your project.',
      image: 'https://images.pexels.com/photos/1181681/pexels-photo-1181681.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2023-12-10',
      readTime: '9 min read',
      views: '1.9K',
      likes: 98,
      comments: 19,
      tags: ['Serverless', 'Containers', 'Architecture']
    }
  ];

  const categories = [
    { name: 'DevOps', count: 24 },
    { name: 'Cloud Computing', count: 18 },
    { name: 'Kubernetes', count: 15 },
    { name: 'Security', count: 12 },
    { name: 'Automation', count: 10 },
    { name: 'Monitoring', count: 8 }
  ];

  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          Technical Blog
        </h2>
        
        {/* Featured Post */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            <div className="relative h-64 lg:h-auto">
              <img 
                src={featuredPost.image} 
                alt={featuredPost.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-600/20"></div>
              <div className="absolute top-4 left-4">
                <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                  Featured
                </span>
              </div>
            </div>
            
            <div className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4 leading-tight">{featuredPost.title}</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">{featuredPost.excerpt}</p>
              
              <div className="flex items-center space-x-4 mb-6 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(featuredPost.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{featuredPost.readTime}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Eye className="w-4 h-4" />
                  <span>{featuredPost.views}</span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {featuredPost.tags.map((tag, i) => (
                  <span key={i} className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded-md text-xs">
                    {tag}
                  </span>
                ))}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Heart className="w-4 h-4" />
                    <span>{featuredPost.likes}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MessageCircle className="w-4 h-4" />
                    <span>{featuredPost.comments}</span>
                  </div>
                </div>
                <button className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg text-sm font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
                  <span>Read More</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Blog Posts */}
          <div className="lg:col-span-3">
            <h3 className="text-2xl font-semibold text-blue-300 mb-6">Recent Posts</h3>
            <div className="space-y-6">
              {blogPosts.map((post, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden hover:bg-white/15 transition-all group">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                    <div className="relative h-48 md:h-auto">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    
                    <div className="md:col-span-2 p-6">
                      <h4 className="text-lg font-semibold text-white mb-3 group-hover:text-blue-300 transition-colors">
                        {post.title}
                      </h4>
                      <p className="text-gray-300 text-sm mb-4 leading-relaxed">{post.excerpt}</p>
                      
                      <div className="flex items-center space-x-4 mb-4 text-xs text-gray-400">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(post.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{post.readTime}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>{post.views}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {post.tags.slice(0, 2).map((tag, i) => (
                            <span key={i} className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded-md text-xs">
                              {tag}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center space-x-3 text-xs text-gray-400">
                          <div className="flex items-center space-x-1">
                            <Heart className="w-3 h-3" />
                            <span>{post.likes}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MessageCircle className="w-3 h-3" />
                            <span>{post.comments}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Load More */}
            <div className="text-center mt-8">
              <button className="px-8 py-3 bg-white/10 border border-white/20 rounded-lg font-medium hover:bg-white/20 transition-all">
                Load More Posts
              </button>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
              <h4 className="text-lg font-semibold text-blue-300 mb-4">Categories</h4>
              <div className="space-y-2">
                {categories.map((category, index) => (
                  <div key={index} className="flex items-center justify-between py-2 border-b border-white/10 last:border-b-0">
                    <span className="text-gray-300 text-sm">{category.name}</span>
                    <span className="text-blue-300 text-sm font-medium">{category.count}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Newsletter */}
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 backdrop-blur-md border border-white/20 rounded-2xl p-6">
              <h4 className="text-lg font-semibold text-white mb-3">Subscribe to Newsletter</h4>
              <p className="text-gray-300 text-sm mb-4">Get the latest DevOps insights and tutorials delivered to your inbox.</p>
              <div className="space-y-3">
                <input 
                  type="email" 
                  placeholder="Enter your email"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                />
                <button className="w-full py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg text-sm font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
                  Subscribe
                </button>
              </div>
            </div>
            
            {/* Popular Tags */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
              <h4 className="text-lg font-semibold text-blue-300 mb-4">Popular Tags</h4>
              <div className="flex flex-wrap gap-2">
                {['DevOps', 'AWS', 'Kubernetes', 'Docker', 'CI/CD', 'Terraform', 'Monitoring', 'Security'].map((tag, index) => (
                  <span key={index} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs hover:bg-blue-500/30 transition-colors cursor-pointer">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;