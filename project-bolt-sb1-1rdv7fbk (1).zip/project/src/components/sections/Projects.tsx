import React from 'react';
import { ExternalLink, Github, Star, GitBranch, Users, Clock } from 'lucide-react';

const Projects: React.FC = () => {
  const projects = [
    {
      title: 'Multi-Cloud Kubernetes Platform',
      description: 'Enterprise-grade Kubernetes platform deployed across AWS, Azure, and GCP with automated failover and disaster recovery.',
      tech: ['Kubernetes', 'Terraform', 'Helm', 'ArgoCD', 'Prometheus'],
      status: 'Production',
      team: '8 members',
      duration: '6 months',
      highlights: ['99.99% uptime', '50% cost reduction', 'Zero-downtime deployments'],
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'AI-Powered CI/CD Pipeline',
      description: 'Intelligent CI/CD system that uses machine learning to predict build failures and optimize deployment strategies.',
      tech: ['Jenkins', 'Python', 'Docker', 'AWS Lambda', 'TensorFlow'],
      status: 'Production',
      team: '5 members',
      duration: '4 months',
      highlights: ['40% faster builds', 'Predictive analytics', 'Auto-scaling runners'],
      image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Serverless Microservices Architecture',
      description: 'Complete serverless architecture using AWS Lambda, API Gateway, and DynamoDB with Infrastructure as Code.',
      tech: ['AWS Lambda', 'API Gateway', 'DynamoDB', 'CloudFormation', 'Node.js'],
      status: 'Production',
      team: '6 members',
      duration: '3 months',
      highlights: ['90% cost savings', 'Auto-scaling', 'Event-driven architecture'],
      image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Container Security Platform',
      description: 'Comprehensive security scanning and compliance platform for containerized applications with automated remediation.',
      tech: ['Docker', 'Kubernetes', 'Falco', 'OPA', 'Grafana'],
      status: 'Beta',
      team: '4 members',
      duration: '5 months',
      highlights: ['Real-time scanning', 'Policy enforcement', 'Compliance reporting'],
      image: 'https://images.pexels.com/photos/1181678/pexels-photo-1181678.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Infrastructure Monitoring Suite',
      description: 'Advanced monitoring and alerting system with custom dashboards and predictive maintenance capabilities.',
      tech: ['Prometheus', 'Grafana', 'ELK Stack', 'Jaeger', 'Python'],
      status: 'Production',
      team: '3 members',
      duration: '2 months',
      highlights: ['Custom metrics', 'Predictive alerts', 'Performance optimization'],
      image: 'https://images.pexels.com/photos/1181679/pexels-photo-1181679.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'GitOps Deployment Framework',
      description: 'Complete GitOps implementation with automated deployments, rollbacks, and environment promotion workflows.',
      tech: ['ArgoCD', 'Flux', 'Kustomize', 'Git', 'Kubernetes'],
      status: 'Production',
      team: '7 members',
      duration: '4 months',
      highlights: ['GitOps workflows', 'Automated rollbacks', 'Environment parity'],
      image: 'https://images.pexels.com/photos/1181680/pexels-photo-1181680.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          Featured Projects
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden hover:bg-white/15 transition-all group">
              {/* Project Image */}
              <div className="h-48 bg-gradient-to-r from-blue-500/20 to-purple-600/20 relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    project.status === 'Production' 
                      ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
                      : 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30'
                  }`}>
                    {project.status}
                  </span>
                </div>
              </div>
              
              {/* Project Content */}
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-blue-300 transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                  {project.description}
                </p>
                
                {/* Project Stats */}
                <div className="flex items-center space-x-4 mb-4 text-xs text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span>{project.team}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{project.duration}</span>
                  </div>
                </div>
                
                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((tech, i) => (
                    <span key={i} className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded-md text-xs">
                      {tech}
                    </span>
                  ))}
                </div>
                
                {/* Highlights */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-blue-300 mb-2">Key Achievements:</h4>
                  <ul className="space-y-1">
                    {project.highlights.map((highlight, i) => (
                      <li key={i} className="flex items-center space-x-2 text-xs text-gray-300">
                        <Star className="w-3 h-3 text-yellow-400" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Action Buttons */}
                <div className="flex space-x-3">
                  <button className="flex items-center space-x-2 px-4 py-2 bg-blue-500/20 border border-blue-500/30 rounded-lg text-sm hover:bg-blue-500/30 transition-all">
                    <ExternalLink className="w-4 h-4" />
                    <span>Live Demo</span>
                  </button>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-sm hover:bg-white/20 transition-all">
                    <Github className="w-4 h-4" />
                    <span>Code</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* View More Projects */}
        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-medium hover:from-blue-400 hover:to-purple-500 transition-all hover:scale-105">
            View All Projects on GitHub
          </button>
        </div>
      </div>
    </div>
  );
};

export default Projects;