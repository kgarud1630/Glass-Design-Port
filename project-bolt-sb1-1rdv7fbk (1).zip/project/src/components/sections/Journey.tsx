import React from 'react';
import { Calendar, MapPin, Award, Briefcase } from 'lucide-react';

const Journey: React.FC = () => {
  const journeyItems = [
    {
      year: '2024',
      title: 'Senior DevOps Engineer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      description: 'Leading cloud migration initiatives and implementing advanced CI/CD pipelines for enterprise clients.',
      achievements: ['Reduced deployment time by 75%', 'Managed $2M+ cloud infrastructure', 'Led team of 8 engineers']
    },
    {
      year: '2022',
      title: 'DevOps Engineer',
      company: 'CloudFirst Inc.',
      location: 'Remote',
      description: 'Specialized in Kubernetes orchestration and AWS infrastructure automation.',
      achievements: ['Implemented GitOps workflows', 'Achieved 99.9% uptime', 'Automated 90% of deployments']
    },
    {
      year: '2020',
      title: 'Cloud Infrastructure Engineer',
      company: 'StartupXYZ',
      location: 'Austin, TX',
      description: 'Built scalable cloud infrastructure from ground up using Infrastructure as Code.',
      achievements: ['Designed multi-region architecture', 'Implemented monitoring solutions', 'Cost optimization: 40% savings']
    },
    {
      year: '2019',
      title: 'System Administrator',
      company: 'Enterprise Corp',
      location: 'Dallas, TX',
      description: 'Managed on-premise infrastructure and began transition to cloud technologies.',
      achievements: ['Maintained 200+ servers', 'Implemented backup strategies', 'Started DevOps transformation']
    }
  ];

  const certifications = [
    { name: 'AWS Solutions Architect Professional', year: '2023', issuer: 'Amazon Web Services' },
    { name: 'Certified Kubernetes Administrator', year: '2022', issuer: 'Cloud Native Computing Foundation' },
    { name: 'Docker Certified Associate', year: '2021', issuer: 'Docker Inc.' },
    { name: 'Terraform Associate', year: '2021', issuer: 'HashiCorp' }
  ];

  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          My Journey
        </h2>

        {/* Career Timeline */}
        <div className="mb-12">
          <h3 className="text-2xl font-semibold mb-8 text-blue-300">Career Timeline</h3>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 to-purple-600"></div>
            
            <div className="space-y-8">
              {journeyItems.map((item, index) => (
                <div key={index} className="relative flex items-start space-x-6">
                  {/* Timeline dot */}
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center border-4 border-slate-900">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="text-xl font-semibold text-white">{item.title}</h4>
                        <p className="text-blue-300 font-medium">{item.company}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-purple-400">{item.year}</span>
                        <div className="flex items-center space-x-1 text-gray-400 text-sm">
                          <MapPin className="w-3 h-3" />
                          <span>{item.location}</span>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-300 mb-4">{item.description}</p>
                    
                    <div className="space-y-2">
                      <h5 className="text-sm font-semibold text-blue-300">Key Achievements:</h5>
                      <ul className="space-y-1">
                        {item.achievements.map((achievement, i) => (
                          <li key={i} className="flex items-center space-x-2 text-sm text-gray-300">
                            <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Certifications */}
        <div>
          <h3 className="text-2xl font-semibold mb-8 text-blue-300">Certifications & Achievements</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-white mb-1">{cert.name}</h4>
                    <p className="text-blue-300 text-sm mb-2">{cert.issuer}</p>
                    <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full">
                      Certified {cert.year}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Skills Evolution */}
        <div className="mt-12">
          <h3 className="text-2xl font-semibold mb-8 text-blue-300">Skills Evolution</h3>
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="w-8 h-8 text-blue-400" />
                </div>
                <h4 className="text-lg font-semibold mb-2">2019-2020</h4>
                <p className="text-sm text-gray-300">System Administration & Infrastructure Management</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="w-8 h-8 text-purple-400" />
                </div>
                <h4 className="text-lg font-semibold mb-2">2020-2022</h4>
                <p className="text-sm text-gray-300">Cloud Migration & Container Orchestration</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="w-8 h-8 text-green-400" />
                </div>
                <h4 className="text-lg font-semibold mb-2">2022-Present</h4>
                <p className="text-sm text-gray-300">Advanced DevOps & AI Integration</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Journey;