import React from 'react';
import { Cloud, Server, Cog, Shield, Monitor, Zap, ArrowRight, CheckCircle } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: Cloud,
      title: 'Cloud Architecture & Migration',
      description: 'Design and implement scalable cloud solutions with seamless migration strategies.',
      features: ['AWS/Azure/GCP Architecture', 'Cloud Migration Planning', 'Cost Optimization', 'Multi-cloud Strategy'],
      price: 'Starting at $5,000',
      popular: false
    },
    {
      icon: Server,
      title: 'Container Orchestration',
      description: 'Kubernetes and Docker solutions for scalable containerized applications.',
      features: ['Kubernetes Setup', 'Container Security', 'Auto-scaling Configuration', 'Service Mesh Implementation'],
      price: 'Starting at $3,500',
      popular: true
    },
    {
      icon: Cog,
      title: 'CI/CD Pipeline Development',
      description: 'Automated deployment pipelines for faster, more reliable software delivery.',
      features: ['Pipeline Design', 'Automated Testing', 'Deployment Automation', 'GitOps Implementation'],
      price: 'Starting at $2,500',
      popular: false
    },
    {
      icon: Shield,
      title: 'Security & Compliance',
      description: 'Implement security best practices and ensure compliance across your infrastructure.',
      features: ['Security Audits', 'Compliance Implementation', 'Vulnerability Scanning', 'Access Management'],
      price: 'Starting at $4,000',
      popular: false
    },
    {
      icon: Monitor,
      title: 'Monitoring & Observability',
      description: 'Comprehensive monitoring solutions with real-time insights and alerting.',
      features: ['Custom Dashboards', 'Real-time Monitoring', 'Log Management', 'Performance Optimization'],
      price: 'Starting at $2,000',
      popular: false
    },
    {
      icon: Zap,
      title: 'Infrastructure as Code',
      description: 'Automate infrastructure provisioning and management with IaC best practices.',
      features: ['Terraform/CloudFormation', 'Infrastructure Automation', 'Version Control', 'Environment Management'],
      price: 'Starting at $3,000',
      popular: false
    }
  ];

  const consultingPackages = [
    {
      name: 'Starter',
      price: '$150/hour',
      description: 'Perfect for small projects and quick consultations',
      features: ['1-on-1 Consultation', 'Architecture Review', 'Best Practices Guide', 'Email Support'],
      cta: 'Get Started'
    },
    {
      name: 'Professional',
      price: '$2,500/week',
      description: 'Ideal for medium-sized projects and implementations',
      features: ['Dedicated Support', 'Implementation Assistance', 'Code Reviews', 'Documentation', 'Slack Support'],
      cta: 'Choose Professional',
      popular: true
    },
    {
      name: 'Enterprise',
      price: 'Custom Pricing',
      description: 'For large-scale transformations and ongoing partnerships',
      features: ['Full DevOps Transformation', 'Team Training', '24/7 Support', 'Custom Solutions', 'On-site Visits'],
      cta: 'Contact Sales'
    }
  ];

  return (
    <div className="flex-1 p-8 space-y-12">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          Services & Solutions
        </h2>
        
        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className={`bg-white/10 backdrop-blur-md border rounded-2xl p-6 hover:bg-white/15 transition-all group relative ${
                service.popular ? 'border-blue-500/50 ring-2 ring-blue-500/20' : 'border-white/20'
              }`}>
                {service.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-1 rounded-full text-xs font-medium">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500/20 to-purple-600/20 rounded-lg flex items-center justify-center">
                    <IconComponent className="w-6 h-6 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">{service.title}</h3>
                </div>
                
                <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                  {service.description}
                </p>
                
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center space-x-2 text-sm text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="flex items-center justify-between">
                  <span className="text-lg font-semibold text-blue-300">{service.price}</span>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-blue-500/20 border border-blue-500/30 rounded-lg text-sm hover:bg-blue-500/30 transition-all group-hover:translate-x-1">
                    <span>Learn More</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Consulting Packages */}
        <div>
          <h3 className="text-3xl font-bold mb-8 text-center text-blue-300">Consulting Packages</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {consultingPackages.map((pkg, index) => (
              <div key={index} className={`bg-white/10 backdrop-blur-md border rounded-2xl p-8 text-center relative ${
                pkg.popular ? 'border-blue-500/50 ring-2 ring-blue-500/20 scale-105' : 'border-white/20'
              }`}>
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-medium">
                      Recommended
                    </span>
                  </div>
                )}
                
                <h4 className="text-2xl font-bold text-white mb-2">{pkg.name}</h4>
                <div className="text-3xl font-bold text-blue-300 mb-4">{pkg.price}</div>
                <p className="text-gray-300 text-sm mb-6">{pkg.description}</p>
                
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-center space-x-2 text-sm text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={`w-full py-3 rounded-lg font-medium transition-all ${
                  pkg.popular 
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500' 
                    : 'bg-white/10 border border-white/20 hover:bg-white/20'
                }`}>
                  {pkg.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 backdrop-blur-md border border-white/20 rounded-2xl p-8 text-center mt-16">
          <h3 className="text-2xl font-bold text-white mb-4">Ready to Transform Your Infrastructure?</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Let's discuss your specific needs and create a custom solution that scales with your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
              Schedule Free Consultation
            </button>
            <button className="px-8 py-3 bg-white/10 border border-white/20 rounded-lg font-medium hover:bg-white/20 transition-all">
              View Case Studies
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;