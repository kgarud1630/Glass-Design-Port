import React from 'react';
import { Download, ArrowRight, ChevronRight, Award, Users } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex-1 flex items-center justify-between p-8">
      <div className="max-w-2xl">
        <h1 className="text-6xl font-bold mb-6 leading-tight">
          Build. Automate.{' '}
          <span className="bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
            Scale.
          </span>
        </h1>
        <h2 className="text-2xl text-gray-300 mb-4">
          I'm Kiran Garud, a Cloud & DevOps Engineer
        </h2>
        <p className="text-lg text-gray-400 mb-8 leading-relaxed">
          Certified AWS Solutions Architect with real-world experience in Cloud Infrastructure, 
          CI/CD, and Automation. Transforming complex systems into scalable, efficient solutions.
        </p>
        <div className="flex space-x-4">
          <button className="flex items-center space-x-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-medium hover:from-blue-400 hover:to-purple-500 transition-all hover:scale-105">
            <Download className="w-5 h-5" />
            <span>Download Resume</span>
          </button>
          <button className="flex items-center space-x-2 px-8 py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full font-medium hover:bg-white/20 transition-all">
            <span>View Projects</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Right Side Cards */}
      <div className="space-y-6">
        {/* Projects Card */}
        <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-2xl font-bold text-blue-300">20+</h3>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </div>
          <p className="text-gray-300 mb-2">Real Projects Deployed</p>
          <p className="text-sm text-gray-400">Production-ready infrastructure solutions across AWS, Azure, and GCP</p>
        </div>

        {/* Certifications Card */}
        <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="flex space-x-2">
              <Award className="w-6 h-6 text-yellow-400" />
              <h3 className="text-xl font-bold">Certifications</h3>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
              <span className="text-sm text-gray-300">AWS Solutions Architect</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span className="text-sm text-gray-300">Kubernetes Administrator</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-sm text-gray-300">Docker Certified Associate</span>
            </div>
          </div>
        </div>

        {/* Testimonials Card */}
        <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Users className="w-6 h-6 text-green-400" />
              <h3 className="text-xl font-bold">Live Testimonials</h3>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </div>
          <div className="flex -space-x-2 mb-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full border-2 border-white/20"></div>
            <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-full border-2 border-white/20"></div>
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full border-2 border-white/20"></div>
            <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full border-2 border-white/20 flex items-center justify-center">
              <span className="text-xs font-bold">+5</span>
            </div>
          </div>
          <p className="text-sm text-gray-300">"Exceptional DevOps skills and AWS expertise. Delivered scalable solutions on time."</p>
        </div>
      </div>
    </div>
  );
};

export default Home;