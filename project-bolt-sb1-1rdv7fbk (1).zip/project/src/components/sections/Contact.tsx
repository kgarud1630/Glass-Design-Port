import React from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle, Calendar, Clock, Globe, Linkedin, Github, Youtube } from 'lucide-react';

const Contact: React.FC = () => {
  const contactMethods = [
    {
      icon: Mail,
      title: 'Email',
      value: 'kiran.garud@email.com',
      description: 'Send me an email anytime',
      action: 'Send Email'
    },
    {
      icon: Phone,
      title: 'Phone',
      value: '+1 (555) 123-4567',
      description: 'Call me during business hours',
      action: 'Call Now'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      value: '+1 (555) 123-4567',
      description: 'Quick messages and updates',
      action: 'Chat on WhatsApp'
    },
    {
      icon: Calendar,
      title: 'Schedule Meeting',
      value: 'Book a consultation',
      description: 'Free 30-minute consultation',
      action: 'Book Meeting'
    }
  ];

  const availability = [
    { day: 'Monday - Friday', time: '9:00 AM - 6:00 PM PST', available: true },
    { day: 'Saturday', time: '10:00 AM - 2:00 PM PST', available: true },
    { day: 'Sunday', time: 'Emergency only', available: false }
  ];

  const socialLinks = [
    { icon: Linkedin, name: 'LinkedIn', url: '#', color: 'text-blue-400' },
    { icon: Github, name: 'GitHub', url: '#', color: 'text-gray-300' },
    { icon: Youtube, name: 'YouTube', url: '#', color: 'text-red-400' },
    { icon: Globe, name: 'Website', url: '#', color: 'text-green-400' }
  ];

  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          Get In Touch
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Send me a message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">First Name</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors"
                    placeholder="John"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Last Name</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors"
                    placeholder="Doe"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Company</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors"
                  placeholder="Your Company"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Project Type</label>
                <select className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-500 transition-colors">
                  <option value="">Select project type</option>
                  <option value="cloud-migration">Cloud Migration</option>
                  <option value="devops-consulting">DevOps Consulting</option>
                  <option value="infrastructure-setup">Infrastructure Setup</option>
                  <option value="ci-cd-implementation">CI/CD Implementation</option>
                  <option value="monitoring-setup">Monitoring & Observability</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Message</label>
                <textarea 
                  rows={5}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  placeholder="Tell me about your project requirements..."
                ></textarea>
              </div>
              
              <button 
                type="submit"
                className="w-full flex items-center justify-center space-x-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all"
              >
                <Send className="w-5 h-5" />
                <span>Send Message</span>
              </button>
            </form>
          </div>
          
          {/* Contact Information */}
          <div className="space-y-8">
            {/* Contact Methods */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
              <h3 className="text-2xl font-semibold text-white mb-6">Contact Information</h3>
              <div className="space-y-6">
                {contactMethods.map((method, index) => {
                  const IconComponent = method.icon;
                  return (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500/20 to-purple-600/20 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-6 h-6 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-white mb-1">{method.title}</h4>
                        <p className="text-blue-300 font-medium mb-1">{method.value}</p>
                        <p className="text-gray-400 text-sm mb-2">{method.description}</p>
                        <button className="text-blue-400 text-sm hover:text-blue-300 transition-colors">
                          {method.action} →
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            {/* Availability */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
              <h3 className="text-2xl font-semibold text-white mb-6 flex items-center space-x-2">
                <Clock className="w-6 h-6 text-blue-400" />
                <span>Availability</span>
              </h3>
              <div className="space-y-4">
                {availability.map((schedule, index) => (
                  <div key={index} className="flex items-center justify-between py-3 border-b border-white/10 last:border-b-0">
                    <div>
                      <p className="text-white font-medium">{schedule.day}</p>
                      <p className="text-gray-400 text-sm">{schedule.time}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      schedule.available 
                        ? 'bg-green-500/20 text-green-300' 
                        : 'bg-red-500/20 text-red-300'
                    }`}>
                      {schedule.available ? 'Available' : 'Limited'}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-300 text-sm">
                  <strong>Note:</strong> Response time is typically within 2-4 hours during business hours.
                </p>
              </div>
            </div>
            
            {/* Location & Social */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
              <div className="mb-6">
                <h3 className="text-2xl font-semibold text-white mb-4 flex items-center space-x-2">
                  <MapPin className="w-6 h-6 text-blue-400" />
                  <span>Location</span>
                </h3>
                <p className="text-gray-300">San Francisco, CA, USA</p>
                <p className="text-gray-400 text-sm">Available for remote work worldwide</p>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold text-white mb-4">Follow Me</h4>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => {
                    const IconComponent = social.icon;
                    return (
                      <a 
                        key={index}
                        href={social.url}
                        className={`w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110 ${social.color}`}
                      >
                        <IconComponent className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mt-12">
          <h3 className="text-2xl font-semibold text-blue-300 mb-8">Frequently Asked Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">What's your typical response time?</h4>
              <p className="text-gray-300 text-sm">I typically respond within 2-4 hours during business hours and within 24 hours on weekends.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">Do you work with international clients?</h4>
              <p className="text-gray-300 text-sm">Yes, I work with clients worldwide and can accommodate different time zones for meetings and support.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">What's included in a consultation?</h4>
              <p className="text-gray-300 text-sm">Free 30-minute consultation includes project assessment, recommendations, and a custom proposal.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-2">Do you provide ongoing support?</h4>
              <p className="text-gray-300 text-sm">Yes, I offer various support packages including monitoring, maintenance, and on-call support.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;