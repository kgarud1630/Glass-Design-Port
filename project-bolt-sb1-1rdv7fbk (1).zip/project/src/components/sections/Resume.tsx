import React from 'react';
import { Download, Mail, Phone, MapPin, Calendar, Award, Briefcase, GraduationCap, Code, Star } from 'lucide-react';

const Resume: React.FC = () => {
  const skills = {
    'Cloud Platforms': ['AWS', 'Azure', 'Google Cloud', 'DigitalOcean'],
    'Container & Orchestration': ['Docker', 'Kubernetes', 'OpenShift', 'Helm'],
    'Infrastructure as Code': ['Terraform', 'CloudFormation', 'Ansible', 'Pulumi'],
    'CI/CD Tools': ['Jenkins', 'GitLab CI', 'GitHub Actions', 'ArgoCD'],
    'Monitoring & Logging': ['Prometheus', 'Grafana', 'ELK Stack', 'Datadog'],
    'Programming': ['Python', 'Go', 'Bash', 'JavaScript', 'YAML']
  };

  const experience = [
    {
      title: 'Senior DevOps Engineer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      period: '2024 - Present',
      responsibilities: [
        'Lead cloud migration initiatives for enterprise clients, reducing infrastructure costs by 40%',
        'Design and implement CI/CD pipelines serving 50+ microservices with 99.9% uptime',
        'Manage multi-cloud infrastructure across AWS, Azure, and GCP with automated disaster recovery',
        'Mentor junior engineers and establish DevOps best practices across the organization'
      ]
    },
    {
      title: 'DevOps Engineer',
      company: 'CloudFirst Inc.',
      location: 'Remote',
      period: '2022 - 2024',
      responsibilities: [
        'Implemented Kubernetes-based container orchestration for 20+ applications',
        'Automated infrastructure provisioning using Terraform, reducing deployment time by 75%',
        'Established comprehensive monitoring and alerting systems using Prometheus and Grafana',
        'Collaborated with development teams to optimize application performance and scalability'
      ]
    },
    {
      title: 'Cloud Infrastructure Engineer',
      company: 'StartupXYZ',
      location: 'Austin, TX',
      period: '2020 - 2022',
      responsibilities: [
        'Built scalable cloud infrastructure from ground up supporting 1M+ daily users',
        'Implemented GitOps workflows and automated deployment processes',
        'Designed and maintained high-availability systems with 99.95% uptime SLA',
        'Optimized cloud costs through resource right-sizing and reserved instance strategies'
      ]
    },
    {
      title: 'System Administrator',
      company: 'Enterprise Corp',
      location: 'Dallas, TX',
      period: '2019 - 2020',
      responsibilities: [
        'Managed on-premise infrastructure including 200+ Linux and Windows servers',
        'Implemented backup and disaster recovery solutions ensuring zero data loss',
        'Automated routine tasks using PowerShell and Bash scripts, improving efficiency by 60%',
        'Led the initial cloud migration planning and proof-of-concept implementations'
      ]
    }
  ];

  const education = [
    {
      degree: 'Bachelor of Science in Computer Science',
      school: 'University of Texas at Austin',
      period: '2015 - 2019',
      details: 'Graduated Magna Cum Laude, GPA: 3.8/4.0'
    }
  ];

  const certifications = [
    {
      name: 'AWS Certified Solutions Architect - Professional',
      issuer: 'Amazon Web Services',
      date: '2023',
      id: 'AWS-SAP-2023-001'
    },
    {
      name: 'Certified Kubernetes Administrator (CKA)',
      issuer: 'Cloud Native Computing Foundation',
      date: '2022',
      id: 'CKA-2022-001'
    },
    {
      name: 'Docker Certified Associate',
      issuer: 'Docker Inc.',
      date: '2021',
      id: 'DCA-2021-001'
    },
    {
      name: 'HashiCorp Certified: Terraform Associate',
      issuer: 'HashiCorp',
      date: '2021',
      id: 'TF-ASSOC-2021-001'
    }
  ];

  return (
    <div className="flex-1 p-8 space-y-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
            Resume
          </h2>
          <button className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
            <Download className="w-5 h-5" />
            <span>Download PDF</span>
          </button>
        </div>
        
        {/* Personal Info */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Kiran Garud</h1>
              <p className="text-xl text-blue-300 mb-4">Senior DevOps Engineer</p>
              <p className="text-gray-300 leading-relaxed">
                Experienced DevOps Engineer with 5+ years of expertise in cloud infrastructure, 
                automation, and scalable system design. Passionate about bridging development 
                and operations through innovative solutions.
              </p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-gray-300">
                <Mail className="w-5 h-5 text-blue-400" />
                <span>kiran.garud@email.com</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Phone className="w-5 h-5 text-blue-400" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <MapPin className="w-5 h-5 text-blue-400" />
                <span>San Francisco, CA</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Skills */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mb-8">
          <h3 className="text-2xl font-semibold text-blue-300 mb-6 flex items-center space-x-2">
            <Code className="w-6 h-6" />
            <span>Technical Skills</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(skills).map(([category, skillList], index) => (
              <div key={index}>
                <h4 className="text-lg font-semibold text-white mb-3">{category}</h4>
                <div className="flex flex-wrap gap-2">
                  {skillList.map((skill, i) => (
                    <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Experience */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mb-8">
          <h3 className="text-2xl font-semibold text-blue-300 mb-6 flex items-center space-x-2">
            <Briefcase className="w-6 h-6" />
            <span>Professional Experience</span>
          </h3>
          <div className="space-y-8">
            {experience.map((job, index) => (
              <div key={index} className="relative">
                {index !== experience.length - 1 && (
                  <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-blue-500/30"></div>
                )}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xl font-semibold text-white">{job.title}</h4>
                      <span className="text-blue-300 font-medium">{job.period}</span>
                    </div>
                    <div className="flex items-center space-x-2 mb-4">
                      <span className="text-purple-300 font-medium">{job.company}</span>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-400">{job.location}</span>
                    </div>
                    <ul className="space-y-2">
                      {job.responsibilities.map((responsibility, i) => (
                        <li key={i} className="flex items-start space-x-2 text-gray-300">
                          <Star className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{responsibility}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Education & Certifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Education */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-blue-300 mb-6 flex items-center space-x-2">
              <GraduationCap className="w-6 h-6" />
              <span>Education</span>
            </h3>
            {education.map((edu, index) => (
              <div key={index} className="mb-6 last:mb-0">
                <h4 className="text-lg font-semibold text-white mb-2">{edu.degree}</h4>
                <p className="text-purple-300 font-medium mb-1">{edu.school}</p>
                <div className="flex items-center space-x-2 text-gray-400 text-sm mb-2">
                  <Calendar className="w-4 h-4" />
                  <span>{edu.period}</span>
                </div>
                <p className="text-gray-300 text-sm">{edu.details}</p>
              </div>
            ))}
          </div>
          
          {/* Certifications */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-blue-300 mb-6 flex items-center space-x-2">
              <Award className="w-6 h-6" />
              <span>Certifications</span>
            </h3>
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <div key={index} className="border-b border-white/10 pb-4 last:border-b-0 last:pb-0">
                  <h4 className="text-lg font-semibold text-white mb-1">{cert.name}</h4>
                  <p className="text-purple-300 text-sm mb-1">{cert.issuer}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-sm">{cert.date}</span>
                    <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full">
                      Verified
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Download CTA */}
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 backdrop-blur-md border border-white/20 rounded-2xl p-8 text-center mt-8">
          <h3 className="text-2xl font-bold text-white mb-4">Download Complete Resume</h3>
          <p className="text-gray-300 mb-6">
            Get the full PDF version with additional details and references.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="flex items-center space-x-2 px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
              <Download className="w-5 h-5" />
              <span>Download PDF Resume</span>
            </button>
            <button className="px-8 py-3 bg-white/10 border border-white/20 rounded-lg font-medium hover:bg-white/20 transition-all">
              Print Resume
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Resume;