import React from 'react';

interface NavigationProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeSection, setActiveSection }) => {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'journey', label: 'Journey' },
    { id: 'projects', label: 'Projects' },
    { id: 'services', label: 'Services' },
    { id: 'architecture', label: 'Architecture' },
    { id: 'ai-compatible', label: 'AI Compatible' },
    { id: 'blog', label: 'Blog' },
    { id: 'resume', label: 'Resume' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <nav className="p-8 pb-0">
      <div className="flex items-center justify-between">
        <div className="flex space-x-2 overflow-x-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`px-6 py-2 backdrop-blur-sm border rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                activeSection === item.id
                  ? 'bg-blue-500/20 border-blue-500/30 text-blue-300'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="flex space-x-3 ml-4">
          <button 
            onClick={() => setActiveSection('contact')}
            className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all"
          >
            Contact
          </button>
          <button className="px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full text-sm font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
            Hire Me
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;