import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';

// Import all sections
import Home from './components/sections/Home';
import About from './components/sections/About';
import Journey from './components/sections/Journey';
import Projects from './components/sections/Projects';
import Services from './components/sections/Services';
import Architecture from './components/sections/Architecture';
import AICompatible from './components/sections/AICompatible';
import Blog from './components/sections/Blog';
import Resume from './components/sections/Resume';
import Contact from './components/sections/Contact';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  const renderSection = () => {
    switch (activeSection) {
      case 'home':
        return <Home />;
      case 'about':
        return <About />;
      case 'journey':
        return <Journey />;
      case 'projects':
        return <Projects />;
      case 'services':
        return <Services />;
      case 'architecture':
        return <Architecture />;
      case 'ai-compatible':
        return <AICompatible />;
      case 'blog':
        return <Blog />;
      case 'resume':
        return <Resume />;
      case 'contact':
        return <Contact />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-hidden relative">
      {/* Dynamic 3D Animated Background */}
      <div className="fixed inset-0 overflow-hidden">
        {/* Main flowing shapes */}
        <div className="absolute top-0 left-0 w-full h-full">
          {/* Large morphing blob 1 */}
          <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-gradient-to-r from-blue-500/30 to-purple-600/30 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
          
          {/* Large morphing blob 2 */}
          <div className="absolute top-1/2 right-1/4 w-80 h-80 bg-gradient-to-r from-purple-500/40 to-indigo-600/40 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
          
          {/* Large morphing blob 3 */}
          <div className="absolute bottom-1/3 left-1/4 w-72 h-72 bg-gradient-to-r from-indigo-500/35 to-blue-600/35 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
          
          {/* Flowing liquid shapes */}
          <div className="absolute top-1/6 right-1/3 w-64 h-96 bg-gradient-to-b from-blue-400/20 to-purple-500/20 rounded-full mix-blend-multiply filter blur-2xl animate-float"></div>
          
          <div className="absolute bottom-1/4 right-1/2 w-48 h-64 bg-gradient-to-t from-purple-400/25 to-indigo-500/25 rounded-full mix-blend-multiply filter blur-2xl animate-float animation-delay-3000"></div>
          
          {/* Smaller accent shapes */}
          <div className="absolute top-1/3 left-1/6 w-32 h-32 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full mix-blend-multiply filter blur-lg animate-pulse-slow"></div>
          
          <div className="absolute bottom-1/2 right-1/6 w-24 h-24 bg-gradient-to-r from-purple-400/40 to-pink-500/40 rounded-full mix-blend-multiply filter blur-lg animate-pulse-slow animation-delay-1000"></div>
          
          {/* Flowing streaks */}
          <div className="absolute top-0 left-1/2 w-1 h-full bg-gradient-to-b from-transparent via-blue-400/20 to-transparent animate-flow"></div>
          <div className="absolute top-0 right-1/3 w-1 h-full bg-gradient-to-b from-transparent via-purple-400/20 to-transparent animate-flow animation-delay-2000"></div>
        </div>
        
        {/* Overlay gradient for depth */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-purple-900/30"></div>
      </div>

      <div className="relative z-10 flex min-h-screen">
        {/* Left Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Navigation */}
          <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />

          {/* Dynamic Content */}
          {renderSection()}
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;