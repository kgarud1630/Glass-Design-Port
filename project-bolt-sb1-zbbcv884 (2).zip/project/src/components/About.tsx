import React from 'react';
import { Heart, Target, Lightbulb, Users } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Excellence',
      description: 'Committed to delivering high-quality solutions that exceed expectations and drive business value.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Always exploring cutting-edge technologies and methodologies to solve complex challenges.'
    },
    {
      icon: Users,
      title: 'Collaboration',
      description: 'Believe in the power of teamwork and building strong relationships across all stakeholders.'
    },
    {
      icon: Heart,
      title: 'Passion',
      description: 'Genuinely passionate about technology and its potential to transform businesses.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Passionate about building scalable, reliable systems that empower teams and drive innovation
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Personal Story */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">
              My Journey in DevOps
            </h3>
            <div className="space-y-4 text-gray-600 dark:text-gray-300 leading-relaxed">
              <p>
                My journey into DevOps began over 8 years ago when I realized the power of automation 
                and cloud technologies to transform how we build and deploy software. What started as 
                curiosity about optimizing deployment processes has evolved into a deep passion for 
                creating resilient, scalable infrastructure.
              </p>
              <p>
                I've had the privilege of working with diverse teams across startups to Fortune 500 
                companies, helping them modernize their infrastructure, implement CI/CD pipelines, 
                and embrace cloud-native solutions. Each challenge has taught me something new about 
                the intersection of technology, process, and people.
              </p>
              <p>
                When I'm not architecting cloud solutions, you'll find me contributing to open source 
                projects, mentoring junior engineers, or exploring the latest in containerization and 
                orchestration technologies. I believe in continuous learning and sharing knowledge 
                with the community.
              </p>
            </div>
          </div>

          {/* Profile Image */}
          <div className="relative">
            <div className="w-full h-96 bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900 dark:to-secondary-900 rounded-2xl flex items-center justify-center">
              <div className="text-6xl font-bold text-primary-600 dark:text-primary-400">AJ</div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-accent-500 rounded-full flex items-center justify-center">
              <Heart className="h-8 w-8 text-white animate-pulse" />
            </div>
          </div>
        </div>

        {/* Core Values */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white text-center mb-12">
            Core Values That Drive My Work
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div 
                  key={index}
                  className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-xl hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-primary-600 dark:text-primary-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {value.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Technical Interests */}
        <div className="mt-16 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-2xl p-8">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white text-center mb-8">
            Current Technical Interests
          </h3>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-900 dark:text-white">AI/ML Operations</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Exploring MLOps, model deployment, and AI-powered automation
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-900 dark:text-white">GitOps</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Implementing GitOps workflows with ArgoCD and Flux
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-900 dark:text-white">FinOps</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Cloud cost optimization and financial operations
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;