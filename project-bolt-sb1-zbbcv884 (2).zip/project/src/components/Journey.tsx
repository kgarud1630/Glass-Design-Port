import React from 'react';
import { Briefcase, GraduationCap, Award, Calendar } from 'lucide-react';

const Journey = () => {
  const experiences = [
    {
      type: 'work',
      title: 'Staff DevOps Engineer',
      company: 'TechFlow Solutions',
      period: '2022 - Present',
      location: 'San Francisco, CA',
      description: 'Leading DevOps transformation initiatives for enterprise clients. Architected multi-cloud infrastructure serving 10M+ users.',
      achievements: [
        'Reduced deployment time by 80% through CI/CD optimization',
        'Implemented zero-downtime deployments across 15+ microservices',
        'Led cloud migration saving $2M annually in infrastructure costs'
      ],
      skills: ['AWS', 'Kubernetes', 'Terraform', 'GitLab CI', 'Python']
    },
    {
      type: 'work',
      title: 'Senior DevOps Engineer',
      company: 'CloudScale Inc',
      period: '2020 - 2022',
      location: 'Remote',
      description: 'Built and maintained scalable cloud infrastructure for high-growth startups. Specialized in container orchestration.',
      achievements: [
        'Designed auto-scaling architecture handling 1000% traffic spikes',
        'Implemented comprehensive monitoring reducing MTTR by 60%',
        'Mentored team of 5 junior DevOps engineers'
      ],
      skills: ['Azure', 'Docker', 'Ansible', 'Prometheus', 'Grafana']
    },
    {
      type: 'work',
      title: 'DevOps Engineer',
      company: 'StartupVenture',
      period: '2018 - 2020',
      location: 'Austin, TX',
      description: 'Established DevOps practices from ground up. Built first automated deployment pipelines and monitoring systems.',
      achievements: [
        'Created company\'s first CI/CD pipeline from scratch',
        'Implemented Infrastructure as Code reducing provisioning time by 90%',
        'Achieved 99.9% uptime through proactive monitoring'
      ],
      skills: ['GCP', 'Jenkins', 'Chef', 'Bash', 'MySQL']
    },
    {
      type: 'education',
      title: 'Master of Science in Computer Science',
      company: 'Stanford University',
      period: '2014 - 2016',
      location: 'Stanford, CA',
      description: 'Specialized in Distributed Systems and Cloud Computing. Thesis on container orchestration optimization.',
      achievements: [
        'GPA: 3.8/4.0',
        'Teaching Assistant for Cloud Computing course',
        'Published research on container scheduling algorithms'
      ],
      skills: []
    },
    {
      type: 'work',
      title: 'Systems Administrator',
      company: 'DataCorp Systems',
      period: '2016 - 2018',
      location: 'Denver, CO',
      description: 'Managed on-premise infrastructure and began transition to cloud-based solutions.',
      achievements: [
        'Migrated legacy systems to AWS reducing costs by 40%',
        'Automated backup processes improving reliability',
        'Implemented security best practices achieving SOC2 compliance'
      ],
      skills: ['Linux', 'VMware', 'AWS', 'PowerShell', 'PostgreSQL']
    },
    {
      type: 'education',
      title: 'Bachelor of Science in Information Technology',
      company: 'University of Colorado Boulder',
      period: '2012 - 2014',
      location: 'Boulder, CO',
      description: 'Foundation in computer science, networking, and system administration.',
      achievements: [
        'Magna Cum Laude graduate',
        'President of Linux User Group',
        'Completed internship at local tech startup'
      ],
      skills: []
    }
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'work':
        return Briefcase;
      case 'education':
        return GraduationCap;
      default:
        return Award;
    }
  };

  return (
    <section id="journey" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            My Journey
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            From systems administration to leading DevOps transformations - here's how I've grown
          </p>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-primary-200 dark:bg-primary-800"></div>

          {/* Timeline Items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => {
              const Icon = getIcon(exp.type);
              return (
                <div key={index} className="relative flex items-start">
                  {/* Timeline Dot */}
                  <div className="absolute left-6 flex items-center justify-center">
                    <div className={`w-4 h-4 rounded-full ${
                      exp.type === 'work' 
                        ? 'bg-primary-600' 
                        : 'bg-secondary-600'
                    } border-4 border-white dark:border-gray-800`}></div>
                  </div>

                  {/* Content */}
                  <div className="ml-16 w-full">
                    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg ${
                            exp.type === 'work' 
                              ? 'bg-primary-100 dark:bg-primary-900' 
                              : 'bg-secondary-100 dark:bg-secondary-900'
                          }`}>
                            <Icon className={`h-5 w-5 ${
                              exp.type === 'work' 
                                ? 'text-primary-600 dark:text-primary-400' 
                                : 'text-secondary-600 dark:text-secondary-400'
                            }`} />
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                              {exp.title}
                            </h3>
                            <p className="text-primary-600 dark:text-primary-400 font-medium">
                              {exp.company}
                            </p>
                          </div>
                        </div>
                        <div className="text-right text-sm text-gray-500 dark:text-gray-400">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {exp.period}
                          </div>
                          <div className="mt-1">{exp.location}</div>
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
                        {exp.description}
                      </p>

                      {/* Achievements */}
                      <div className="mb-4">
                        <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Key Achievements:
                        </h4>
                        <ul className="space-y-1">
                          {exp.achievements.map((achievement, idx) => (
                            <li key={idx} className="text-sm text-gray-600 dark:text-gray-300 flex items-start">
                              <span className="text-primary-500 mr-2 mt-1">•</span>
                              {achievement}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Skills */}
                      {exp.skills.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {exp.skills.map((skill, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Milestones Summary */}
        <div className="mt-16 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-2xl p-8">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white text-center mb-8">
            Journey Milestones
          </h3>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">2016</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Started Career</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">2018</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">First DevOps Role</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">2020</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Senior Position</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">2022</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Staff Engineer</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Journey;