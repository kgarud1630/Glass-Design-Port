import React, { useState } from 'react';
import { 
  ExternalLink, 
  Github, 
  ArrowRight, 
  Cloud, 
  Container, 
  Shield, 
  Monitor,
  Zap,
  DollarSign,
  Mail
} from 'lucide-react';

const Projects = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'cloud-migration', name: 'Cloud Migration' },
    { id: 'cicd', name: 'CI/CD' },
    { id: 'monitoring', name: 'Monitoring' },
    { id: 'security', name: 'Security' },
    { id: 'automation', name: 'Automation' }
  ];

  const projects = [
    {
      id: 1,
      title: 'Enterprise Cloud Migration',
      category: 'cloud-migration',
      description: 'Led complete migration of legacy infrastructure to AWS, serving 50M+ users with zero downtime.',
      longDescription: 'Orchestrated the migration of a monolithic e-commerce platform to microservices architecture on AWS. The project involved containerizing 25+ services, implementing auto-scaling, and establishing disaster recovery procedures.',
      image: 'https://images.pexels.com/photos/5935791/pexels-photo-5935791.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['AWS', 'Kubernetes', 'Terraform', 'Docker', 'CloudFormation'],
      icon: Cloud,
      color: 'primary',
      metrics: {
        'Cost Reduction': '60%',
        'Performance Improvement': '200%',
        'Deployment Speed': '10x faster'
      },
      challenge: 'Migrate legacy monolith without service interruption',
      solution: 'Phased migration using blue-green deployments and feature flags',
      impact: 'Reduced infrastructure costs by $2M annually while improving reliability',
      github: 'https://github.com/alexjohnson/enterprise-migration',
      demo: 'https://migration-demo.example.com',
      featured: true
    },
    {
      id: 2,
      title: 'Multi-Cloud CI/CD Pipeline',
      category: 'cicd',
      description: 'Built unified deployment pipeline supporting AWS, Azure, and GCP with automated testing and rollback.',
      longDescription: 'Designed and implemented a sophisticated CI/CD pipeline that could deploy applications across multiple cloud providers simultaneously, with automated testing, security scanning, and intelligent rollback mechanisms.',
      image: 'https://images.pexels.com/photos/7988079/pexels-photo-7988079.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['GitLab CI', 'Terraform', 'Ansible', 'Docker', 'Python'],
      icon: Zap,
      color: 'accent',
      metrics: {
        'Deployment Time': '15 min → 3 min',
        'Success Rate': '99.8%',
        'Developer Productivity': '40% increase'
      },
      challenge: 'Standardize deployments across multiple cloud platforms',
      solution: 'Infrastructure abstraction layer with unified API',
      impact: 'Accelerated feature delivery by 3x across all teams',
      github: 'https://github.com/alexjohnson/multi-cloud-pipeline',
      demo: 'https://pipeline-demo.example.com',
      featured: true
    },
    {
      id: 3,
      title: 'Kubernetes Security Hardening',
      category: 'security',
      description: 'Implemented comprehensive security framework for Kubernetes clusters with policy enforcement.',
      longDescription: 'Developed a complete security framework for Kubernetes including network policies, pod security policies, RBAC, and runtime security monitoring using Falco and OPA Gatekeeper.',
      image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Kubernetes', 'Falco', 'OPA', 'Istio', 'Vault'],
      icon: Shield,
      color: 'secondary',
      metrics: {
        'Security Score': '95/100',
        'Compliance': 'SOC2 Type II',
        'Incident Reduction': '80%'
      },
      challenge: 'Secure multi-tenant Kubernetes environment',
      solution: 'Defense-in-depth strategy with automated policy enforcement',
      impact: 'Achieved SOC2 compliance and reduced security incidents by 80%',
      github: 'https://github.com/alexjohnson/k8s-security',
      demo: null,
      featured: false
    },
    {
      id: 4,
      title: 'AI-Powered Infrastructure Monitoring',
      category: 'monitoring',
      description: 'Built intelligent monitoring system using ML to predict and prevent infrastructure failures.',
      longDescription: 'Created an advanced monitoring solution that uses machine learning algorithms to analyze infrastructure metrics, predict potential failures, and automatically trigger remediation actions.',
      image: 'https://images.pexels.com/photos/7988748/pexels-photo-7988748.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Prometheus', 'Grafana', 'Python', 'TensorFlow', 'Elasticsearch'],
      icon: Monitor,
      color: 'primary',
      metrics: {
        'MTTR Reduction': '70%',
        'Prediction Accuracy': '94%',
        'False Positives': '<5%'
      },
      challenge: 'Proactively identify infrastructure issues before they impact users',
      solution: 'ML-based anomaly detection with automated remediation',
      impact: 'Prevented 95% of potential outages, saving $500K in incident costs',
      github: 'https://github.com/alexjohnson/ai-monitoring',
      demo: 'https://monitoring-demo.example.com',
      featured: true
    },
    {
      id: 5,
      title: 'Cost Optimization Framework',
      category: 'automation',
      description: 'Automated cloud cost optimization saving $3M annually through intelligent resource management.',
      longDescription: 'Developed a comprehensive FinOps solution that continuously monitors cloud usage, identifies optimization opportunities, and automatically implements cost-saving measures while maintaining performance.',
      image: 'https://images.pexels.com/photos/7947664/pexels-photo-7947664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Python', 'AWS Cost Explorer', 'Lambda', 'CloudWatch', 'Terraform'],
      icon: DollarSign,
      color: 'accent',
      metrics: {
        'Cost Savings': '$3M annually',
        'Resource Utilization': '+45%',
        'Optimization Speed': 'Real-time'
      },
      challenge: 'Optimize cloud costs without impacting performance',
      solution: 'Automated rightsizing and intelligent scheduling',
      impact: 'Reduced overall cloud spend by 35% while improving performance',
      github: 'https://github.com/alexjohnson/cost-optimizer',
      demo: 'https://cost-demo.example.com',
      featured: false
    },
    {
      id: 6,
      title: 'GitOps Deployment Platform',
      category: 'cicd',
      description: 'Implemented GitOps workflow with ArgoCD for declarative application deployment and management.',
      longDescription: 'Built a complete GitOps platform using ArgoCD that enables declarative application deployment, automated syncing, and progressive delivery patterns across multiple environments.',
      image: 'https://images.pexels.com/photos/7947664/pexels-photo-7947664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['ArgoCD', 'Kubernetes', 'Helm', 'Git', 'Kustomize'],
      icon: Container,
      color: 'secondary',
      metrics: {
        'Deployment Frequency': '50+ per day',
        'Mean Lead Time': '2 hours',
        'Change Failure Rate': '<2%'
      },
      challenge: 'Implement true GitOps with self-healing deployments',
      solution: 'ArgoCD with custom controllers and policies',
      impact: 'Improved deployment reliability and developer experience',
      github: 'https://github.com/alexjohnson/gitops-platform',
      demo: null,
      featured: false
    }
  ];

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  const featuredProjects = projects.filter(project => project.featured);

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'primary':
        return {
          bg: 'bg-primary-100 dark:bg-primary-900',
          text: 'text-primary-600 dark:text-primary-400',
          border: 'border-primary-200 dark:border-primary-800',
          button: 'bg-primary-600 hover:bg-primary-700'
        };
      case 'secondary':
        return {
          bg: 'bg-secondary-100 dark:bg-secondary-900',
          text: 'text-secondary-600 dark:text-secondary-400',
          border: 'border-secondary-200 dark:border-secondary-800',
          button: 'bg-secondary-600 hover:bg-secondary-700'
        };
      case 'accent':
        return {
          bg: 'bg-accent-100 dark:bg-accent-900',
          text: 'text-accent-600 dark:text-accent-400',
          border: 'border-accent-200 dark:border-accent-800',
          button: 'bg-accent-600 hover:bg-accent-700'
        };
      default:
        return {
          bg: 'bg-gray-100 dark:bg-gray-900',
          text: 'text-gray-600 dark:text-gray-400',
          border: 'border-gray-200 dark:border-gray-800',
          button: 'bg-gray-600 hover:bg-gray-700'
        };
    }
  };

  return (
    <section id="projects" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Featured Projects
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Showcasing real-world DevOps solutions that have driven significant business impact
          </p>
        </div>

        {/* Featured Projects Highlight */}
        <div className="mb-12">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-8 text-center">
            🌟 Flagship Projects
          </h3>
          <div className="grid lg:grid-cols-2 gap-8">
            {featuredProjects.slice(0, 2).map((project) => {
              const Icon = project.icon;
              const colors = getColorClasses(project.color);
              
              return (
                <div 
                  key={project.id}
                  className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300"
                >
                  <div className="h-48 bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <div className={`p-3 rounded-lg ${colors.bg}`}>
                        <Icon className={`h-6 w-6 ${colors.text}`} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {project.title}
                    </h4>
                    <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                      {project.longDescription}
                    </p>
                    
                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      {Object.entries(project.metrics).map(([key, value], index) => (
                        <div key={index} className="text-center">
                          <div className={`text-lg font-bold ${colors.text}`}>{value}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{key}</div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.slice(0, 4).map((tag, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded"
                        >
                          {tag}
                        </span>
                      ))}
                      {project.tags.length > 4 && (
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          +{project.tags.length - 4} more
                        </span>
                      )}
                    </div>
                    
                    {/* Actions */}
                    <div className="flex space-x-3">
                      {project.github && (
                        <a
                          href={project.github}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                        >
                          <Github className="h-4 w-4 mr-2" />
                          Code
                        </a>
                      )}
                      {project.demo && (
                        <a
                          href={project.demo}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`flex items-center px-4 py-2 text-white rounded-lg transition-colors duration-200 ${colors.button}`}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Demo
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                selectedCategory === category.id
                  ? 'bg-primary-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* All Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => {
            const Icon = project.icon;
            const colors = getColorClasses(project.color);
            
            return (
              <div 
                key={project.id}
                className="bg-white dark:bg-gray-900 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
              >
                <div className="h-40 bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <div className={`p-2 rounded-lg ${colors.bg}`}>
                      <Icon className={`h-5 w-5 ${colors.text}`} />
                    </div>
                  </div>
                  {project.featured && (
                    <div className="absolute top-3 right-3">
                      <span className="px-2 py-1 bg-yellow-500 text-white text-xs rounded-full">
                        Featured
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {project.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                    {project.description}
                  </p>
                  
                  {/* Key Metric */}
                  <div className="mb-4">
                    <div className={`text-sm font-semibold ${colors.text}`}>
                      {Object.keys(project.metrics)[0]}: {Object.values(project.metrics)[0]}
                    </div>
                  </div>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {project.tags.slice(0, 3).map((tag, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  {/* Actions */}
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      {project.github && (
                        <a
                          href={project.github}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors duration-200"
                        >
                          <Github className="h-4 w-4" />
                        </a>
                      )}
                      {project.demo && (
                        <a
                          href={project.demo}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors duration-200"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                    
                    <button className={`text-sm font-medium flex items-center ${colors.text} hover:underline`}>
                      Learn More
                      <ArrowRight className="h-3 w-3 ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Contact CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              Interested in Similar Solutions?
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
              I love tackling complex DevOps challenges and building solutions that drive real business impact. 
              Let's discuss how I can help with your infrastructure needs.
            </p>
            <button className="inline-flex items-center px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors duration-200">
              <Mail className="h-5 w-5 mr-2" />
              Discuss Your Project
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;