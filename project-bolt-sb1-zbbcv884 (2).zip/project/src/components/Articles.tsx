import React from 'react';
import { Calendar, Clock, ArrowRight, BookOpen, TrendingUp, Users } from 'lucide-react';

const Articles = () => {
  const articles = [
    {
      id: 1,
      title: 'The Complete Guide to Multi-Cloud Kubernetes Management',
      excerpt: 'Learn how to effectively manage Kubernetes clusters across AWS, Azure, and GCP with unified monitoring and deployment strategies.',
      category: 'Tutorial',
      readTime: '12 min',
      publishDate: '2024-01-15',
      image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Kubernetes', 'Multi-Cloud', 'DevOps'],
      views: '2.5K',
      featured: true
    },
    {
      id: 2,
      title: 'Infrastructure as Code Best Practices with Terraform',
      excerpt: 'Discover proven patterns and practices for managing large-scale infrastructure using Terraform modules and state management.',
      category: 'Best Practices',
      readTime: '8 min',
      publishDate: '2024-01-10',
      image: 'https://images.pexels.com/photos/7947664/pexels-photo-7947664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Terraform', 'IaC', 'AWS'],
      views: '1.8K',
      featured: false
    },
    {
      id: 3,
      title: 'Zero-Downtime Deployments: Blue-Green vs Rolling Updates',
      excerpt: 'Compare deployment strategies and learn when to use blue-green deployments versus rolling updates for your applications.',
      category: 'Comparison',
      readTime: '10 min',
      publishDate: '2024-01-05',
      image: 'https://images.pexels.com/photos/7988079/pexels-photo-7988079.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['CI/CD', 'Deployment', 'Kubernetes'],
      views: '3.2K',
      featured: true
    },
    {
      id: 4,
      title: 'Cost Optimization Strategies for Cloud Infrastructure',
      excerpt: 'Practical techniques to reduce cloud costs by 30-50% without compromising performance or reliability.',
      category: 'Guide',
      readTime: '15 min',
      publishDate: '2023-12-28',
      image: 'https://images.pexels.com/photos/5935791/pexels-photo-5935791.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['FinOps', 'AWS', 'Cost Optimization'],
      views: '4.1K',
      featured: false
    },
    {
      id: 5,
      title: 'Monitoring Microservices: Observability Patterns',
      excerpt: 'Implement comprehensive monitoring for microservices using Prometheus, Grafana, and distributed tracing.',
      category: 'Tutorial',
      readTime: '14 min',
      publishDate: '2023-12-20',
      image: 'https://images.pexels.com/photos/7988748/pexels-photo-7988748.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Monitoring', 'Microservices', 'Observability'],
      views: '2.7K',
      featured: true
    },
    {
      id: 6,
      title: 'Security Automation in DevOps Pipelines',
      excerpt: 'Integrate security scanning, policy enforcement, and compliance checks into your CI/CD workflows.',
      category: 'Security',
      readTime: '11 min',
      publishDate: '2023-12-15',
      image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Security', 'DevSecOps', 'Automation'],
      views: '1.9K',
      featured: false
    }
  ];

  const categories = [
    { name: 'Tutorial', count: 12, icon: BookOpen, color: 'primary' },
    { name: 'Best Practices', count: 8, icon: TrendingUp, color: 'secondary' },
    { name: 'Industry Insights', count: 6, icon: Users, color: 'accent' }
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'tutorial':
        return 'bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200';
      case 'best practices':
        return 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900 dark:text-secondary-200';
      case 'guide':
        return 'bg-accent-100 text-accent-800 dark:bg-accent-900 dark:text-accent-200';
      case 'security':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'comparison':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
  };

  const featuredArticles = articles.filter(article => article.featured);
  const recentArticles = articles.slice(0, 6);

  return (
    <section id="articles" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Articles & Insights
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Sharing knowledge and insights from real-world DevOps challenges and solutions
          </p>
        </div>

        {/* Content Categories */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div key={index} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 text-center">
                <div className={`w-12 h-12 mx-auto mb-4 rounded-lg flex items-center justify-center ${
                  category.color === 'primary' ? 'bg-primary-100 dark:bg-primary-900' :
                  category.color === 'secondary' ? 'bg-secondary-100 dark:bg-secondary-900' :
                  'bg-accent-100 dark:bg-accent-900'
                }`}>
                  <Icon className={`h-6 w-6 ${
                    category.color === 'primary' ? 'text-primary-600 dark:text-primary-400' :
                    category.color === 'secondary' ? 'text-secondary-600 dark:text-secondary-400' :
                    'text-accent-600 dark:text-accent-400'
                  }`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {category.name}
                </h3>
                <p className="text-2xl font-bold text-primary-600 dark:text-primary-400 mb-1">
                  {category.count}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Articles</p>
              </div>
            );
          })}
        </div>

        {/* Featured Articles */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-8">
            Featured Articles
          </h3>
          <div className="grid lg:grid-cols-2 gap-8">
            {featuredArticles.slice(0, 2).map((article) => (
              <article 
                key={article.id}
                className="bg-gray-50 dark:bg-gray-800 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="h-48 bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
                      {article.category}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4 bg-white dark:bg-gray-800 rounded-full px-3 py-1">
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                      {article.views} views
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2">
                    {article.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
                    {article.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      {formatDate(article.publishDate)}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      {article.readTime} read
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {article.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded border border-gray-200 dark:border-gray-600"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <button className="inline-flex items-center text-primary-600 dark:text-primary-400 font-medium hover:underline">
                    Read Full Article
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Recent Articles Grid */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-8">
            Recent Articles
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentArticles.map((article) => (
              <article 
                key={article.id}
                className="bg-gray-50 dark:bg-gray-800 rounded-xl overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="h-32 bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                  {article.featured && (
                    <div className="absolute top-2 right-2">
                      <span className="px-2 py-1 bg-yellow-500 text-white text-xs rounded-full">
                        Featured
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getCategoryColor(article.category)}`}>
                      {article.category}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {article.views} views
                    </span>
                  </div>
                  
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
                    {article.title}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
                    {article.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-3">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {formatDate(article.publishDate)}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {article.readTime}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    {article.tags.slice(0, 2).map((tag, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <button className="text-primary-600 dark:text-primary-400 text-sm font-medium hover:underline flex items-center">
                    Read More
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-16 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
            Stay Updated with DevOps Insights
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
            Get weekly insights on DevOps best practices, cloud technologies, and industry trends 
            delivered straight to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
            <button className="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors duration-200">
              Subscribe
            </button>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-3">
            No spam, unsubscribe at any time. Join 2,500+ DevOps professionals.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Articles;