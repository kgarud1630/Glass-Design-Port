import React from 'react';
import { 
  Cloud, 
  Container, 
  GitBranch, 
  Monitor, 
  Shield, 
  Code, 
  Bot,
  Database,
  Server,
  Settings
} from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Cloud Platforms',
      icon: Cloud,
      color: 'primary',
      skills: [
        { name: 'Amazon Web Services', level: 95, years: '6+ years' },
        { name: 'Microsoft Azure', level: 85, years: '4+ years' },
        { name: 'Google Cloud Platform', level: 80, years: '3+ years' },
        { name: 'Digital Ocean', level: 75, years: '2+ years' }
      ]
    },
    {
      title: 'Containers & Orchestration',
      icon: Container,
      color: 'secondary',
      skills: [
        { name: 'Docker', level: 95, years: '6+ years' },
        { name: 'Kubernetes', level: 90, years: '5+ years' },
        { name: 'Helm', level: 85, years: '3+ years' },
        { name: 'Docker Compose', level: 90, years: '5+ years' }
      ]
    },
    {
      title: 'CI/CD & Version Control',
      icon: GitBranch,
      color: 'accent',
      skills: [
        { name: 'Jenkins', level: 90, years: '5+ years' },
        { name: 'GitLab CI/CD', level: 95, years: '4+ years' },
        { name: 'GitHub Actions', level: 85, years: '3+ years' },
        { name: 'Azure DevOps', level: 80, years: '3+ years' }
      ]
    },
    {
      title: 'Infrastructure as Code',
      icon: Code,
      color: 'primary',
      skills: [
        { name: 'Terraform', level: 95, years: '5+ years' },
        { name: 'CloudFormation', level: 85, years: '4+ years' },
        { name: 'ARM Templates', level: 75, years: '2+ years' },
        { name: 'Pulumi', level: 70, years: '1+ years' }
      ]
    },
    {
      title: 'Configuration Management',
      icon: Settings,
      color: 'secondary',
      skills: [
        { name: 'Ansible', level: 90, years: '5+ years' },
        { name: 'Chef', level: 80, years: '3+ years' },
        { name: 'Puppet', level: 75, years: '2+ years' },
        { name: 'SaltStack', level: 70, years: '2+ years' }
      ]
    },
    {
      title: 'Monitoring & Observability',
      icon: Monitor,
      color: 'accent',
      skills: [
        { name: 'Prometheus', level: 90, years: '4+ years' },
        { name: 'Grafana', level: 95, years: '5+ years' },
        { name: 'ELK Stack', level: 85, years: '4+ years' },
        { name: 'DataDog', level: 80, years: '3+ years' }
      ]
    },
    {
      title: 'Programming Languages',
      icon: Code,
      color: 'primary',
      skills: [
        { name: 'Python', level: 90, years: '6+ years' },
        { name: 'Bash/Shell', level: 95, years: '8+ years' },
        { name: 'Go', level: 75, years: '2+ years' },
        { name: 'PowerShell', level: 80, years: '3+ years' }
      ]
    },
    {
      title: 'Databases',
      icon: Database,
      color: 'secondary',
      skills: [
        { name: 'PostgreSQL', level: 85, years: '5+ years' },
        { name: 'MySQL', level: 80, years: '4+ years' },
        { name: 'MongoDB', level: 75, years: '3+ years' },
        { name: 'Redis', level: 85, years: '4+ years' }
      ]
    },
    {
      title: 'Operating Systems',
      icon: Server,
      color: 'accent',
      skills: [
        { name: 'Linux (Ubuntu/CentOS)', level: 95, years: '8+ years' },
        { name: 'Windows Server', level: 80, years: '4+ years' },
        { name: 'macOS', level: 85, years: '6+ years' }
      ]
    },
    {
      title: 'Security & Compliance',
      icon: Shield,
      color: 'primary',
      skills: [
        { name: 'HashiCorp Vault', level: 85, years: '3+ years' },
        { name: 'OWASP', level: 80, years: '4+ years' },
        { name: 'SOC2 Compliance', level: 85, years: '3+ years' },
        { name: 'AWS Security', level: 90, years: '5+ years' }
      ]
    },
    {
      title: 'AI/Automation Tools',
      icon: Bot,
      color: 'secondary',
      skills: [
        { name: 'GitHub Copilot', level: 85, years: '2+ years' },
        { name: 'ChatGPT/Claude', level: 90, years: '2+ years' },
        { name: 'Zapier', level: 75, years: '2+ years' },
        { name: 'Custom AI Scripts', level: 80, years: '1+ years' }
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'primary':
        return {
          bg: 'bg-primary-100 dark:bg-primary-900',
          text: 'text-primary-600 dark:text-primary-400',
          progress: 'bg-primary-500'
        };
      case 'secondary':
        return {
          bg: 'bg-secondary-100 dark:bg-secondary-900',
          text: 'text-secondary-600 dark:text-secondary-400',
          progress: 'bg-secondary-500'
        };
      case 'accent':
        return {
          bg: 'bg-accent-100 dark:bg-accent-900',
          text: 'text-accent-600 dark:text-accent-400',
          progress: 'bg-accent-500'
        };
      default:
        return {
          bg: 'bg-gray-100 dark:bg-gray-900',
          text: 'text-gray-600 dark:text-gray-400',
          progress: 'bg-gray-500'
        };
    }
  };

  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Tools & Technologies
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            A comprehensive overview of my technical expertise across cloud platforms, DevOps tools, and programming languages
          </p>
        </div>

        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            const colors = getColorClasses(category.color);
            
            return (
              <div 
                key={index}
                className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300"
              >
                {/* Category Header */}
                <div className="flex items-center mb-6">
                  <div className={`p-3 rounded-lg ${colors.bg} mr-4`}>
                    <Icon className={`h-6 w-6 ${colors.text}`} />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {category.title}
                  </h3>
                </div>

                {/* Skills List */}
                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          {skill.name}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {skill.years}
                        </span>
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${colors.progress} transition-all duration-1000 ease-out`}
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                        <span>Proficiency</span>
                        <span>{skill.level}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Skills Summary */}
        <div className="mt-16 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-2xl p-8">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white text-center mb-8">
            Expertise Summary
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary-600 dark:text-primary-400">3</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Major Cloud Platforms</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-secondary-600 dark:text-secondary-400">40+</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Technologies Mastered</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-accent-600 dark:text-accent-400">8+</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Years of Experience</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-primary-600 dark:text-primary-400">12</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Certifications Earned</div>
            </div>
          </div>
        </div>

        {/* Learning Philosophy */}
        <div className="mt-12 text-center">
          <div className="max-w-3xl mx-auto">
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Continuous Learning Philosophy
            </h4>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Technology evolves rapidly, and I believe in staying ahead of the curve. I dedicate time each week 
              to learning new tools, exploring emerging technologies, and contributing to open source projects. 
              My goal is not just to use these technologies, but to understand them deeply and share knowledge 
              with the community.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;