import React from 'react';
import { Github, Linkedin, Twitter, Mail, ArrowUp, Heart, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Journey', href: '#journey' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Articles', href: '#articles' },
    { name: 'Contact', href: '#contact' },
  ];

  const socialLinks = [
    {
      icon: Linkedin,
      label: 'LinkedIn',
      href: 'https://linkedin.com/in/alexjohnson',
      color: 'hover:text-blue-600'
    },
    {
      icon: Github,
      label: 'GitHub',
      href: 'https://github.com/alexjohnson',
      color: 'hover:text-gray-900 dark:hover:text-white'
    },
    {
      icon: Twitter,
      label: 'Twitter',
      href: 'https://twitter.com/alexjohnson',
      color: 'hover:text-blue-400'
    },
    {
      icon: Mail,
      label: 'Email',
      href: 'mailto:alex.johnson@email.com',
      color: 'hover:text-primary-600'
    }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 dark:bg-gray-950 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-72 h-72 bg-primary-500 rounded-full mix-blend-multiply filter blur-xl"></div>
        <div className="absolute bottom-0 right-0 w-72 h-72 bg-secondary-500 rounded-full mix-blend-multiply filter blur-xl"></div>
      </div>

      <div className="relative">
        {/* Main Footer Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Brand & About */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Alex Johnson</h3>
                <p className="text-gray-300 mb-4">
                  Senior DevOps Engineer specializing in cloud infrastructure, CI/CD, and automation. 
                  Passionate about building scalable, reliable systems that empower teams.
                </p>
                <div className="flex items-center text-gray-400 text-sm">
                  <MapPin className="h-4 w-4 mr-2" />
                  San Francisco, CA
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-2">
                <h4 className="text-lg font-semibold text-white">Get in Touch</h4>
                <div className="space-y-1">
                  <a 
                    href="mailto:alex.johnson@email.com"
                    className="block text-gray-300 hover:text-primary-400 transition-colors duration-200"
                  >
                    alex.johnson@email.com
                  </a>
                  <a 
                    href="tel:+15551234567"
                    className="block text-gray-300 hover:text-primary-400 transition-colors duration-200"
                  >
                    +1 (555) 123-4567
                  </a>
                </div>
              </div>

              {/* Social Links */}
              <div className="space-y-3">
                <h4 className="text-lg font-semibold text-white">Connect</h4>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={index}
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`p-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition-all duration-200 text-gray-400 ${social.color}`}
                        aria-label={social.label}
                      >
                        <Icon className="h-5 w-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-6">
              <h4 className="text-lg font-semibold text-white">Quick Links</h4>
              <nav className="space-y-2">
                {quickLinks.map((link, index) => (
                  <button
                    key={index}
                    onClick={() => scrollToSection(link.href)}
                    className="block text-gray-300 hover:text-primary-400 transition-colors duration-200 text-left"
                  >
                    {link.name}
                  </button>
                ))}
              </nav>
            </div>

            {/* Latest Update & Resources */}
            <div className="space-y-6">
              <h4 className="text-lg font-semibold text-white">Resources</h4>
              <div className="space-y-4">
                <a
                  href="/resume.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-gray-300 hover:text-primary-400 transition-colors duration-200"
                >
                  Download Resume
                </a>
                <button
                  onClick={() => scrollToSection('#projects')}
                  className="block text-gray-300 hover:text-primary-400 transition-colors duration-200 text-left"
                >
                  View Portfolio
                </button>
                <button
                  onClick={() => scrollToSection('#articles')}
                  className="block text-gray-300 hover:text-primary-400 transition-colors duration-200 text-left"
                >
                  Read Articles
                </button>
              </div>

              {/* Availability Status */}
              <div className="bg-green-900/20 border border-green-800 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3 animate-pulse"></div>
                  <div>
                    <div className="text-green-300 font-medium text-sm">Available for Work</div>
                    <div className="text-green-400 text-xs">Open to new opportunities</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              {/* Copyright */}
              <div className="flex items-center space-x-4 text-gray-400 text-sm">
                <span>© {currentYear} Alex Johnson. All rights reserved.</span>
                <span className="hidden md:block">•</span>
                <span className="hidden md:block">Last updated: January 2025</span>
              </div>

              {/* Made with love */}
              <div className="flex items-center text-gray-400 text-sm">
                <span>Made with</span>
                <Heart className="h-4 w-4 mx-1 text-red-500 animate-pulse" />
                <span>for the DevOps community</span>
              </div>

              {/* Back to top */}
              <button
                onClick={scrollToTop}
                className="flex items-center space-x-2 text-gray-400 hover:text-primary-400 transition-colors duration-200 group"
                aria-label="Back to top"
              >
                <span className="text-sm">Back to top</span>
                <div className="p-2 bg-gray-800 rounded-lg group-hover:bg-gray-700 transition-colors duration-200">
                  <ArrowUp className="h-4 w-4" />
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Technology Credits */}
        <div className="border-t border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="text-center text-gray-500 text-xs">
              <span>Built with React, TypeScript, Tailwind CSS, and deployed on AWS</span>
              <span className="mx-2">•</span>
              <span>Optimized for performance and accessibility</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;