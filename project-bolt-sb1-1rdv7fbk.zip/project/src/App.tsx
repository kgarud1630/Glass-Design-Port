import React from 'react';
import { Github, Linkedin, Mail, Phone, Youtube, Download, ArrowRight, Server, Cloud, Cog, Award, Users, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-hidden relative">
      {/* Dynamic 3D Animated Background */}
      <div className="fixed inset-0 overflow-hidden">
        {/* Main flowing shapes */}
        <div className="absolute top-0 left-0 w-full h-full">
          {/* Large morphing blob 1 */}
          <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-gradient-to-r from-blue-500/30 to-purple-600/30 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
          
          {/* Large morphing blob 2 */}
          <div className="absolute top-1/2 right-1/4 w-80 h-80 bg-gradient-to-r from-purple-500/40 to-indigo-600/40 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
          
          {/* Large morphing blob 3 */}
          <div className="absolute bottom-1/3 left-1/4 w-72 h-72 bg-gradient-to-r from-indigo-500/35 to-blue-600/35 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
          
          {/* Flowing liquid shapes */}
          <div className="absolute top-1/6 right-1/3 w-64 h-96 bg-gradient-to-b from-blue-400/20 to-purple-500/20 rounded-full mix-blend-multiply filter blur-2xl animate-float"></div>
          
          <div className="absolute bottom-1/4 right-1/2 w-48 h-64 bg-gradient-to-t from-purple-400/25 to-indigo-500/25 rounded-full mix-blend-multiply filter blur-2xl animate-float animation-delay-3000"></div>
          
          {/* Smaller accent shapes */}
          <div className="absolute top-1/3 left-1/6 w-32 h-32 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full mix-blend-multiply filter blur-lg animate-pulse-slow"></div>
          
          <div className="absolute bottom-1/2 right-1/6 w-24 h-24 bg-gradient-to-r from-purple-400/40 to-pink-500/40 rounded-full mix-blend-multiply filter blur-lg animate-pulse-slow animation-delay-1000"></div>
          
          {/* Flowing streaks */}
          <div className="absolute top-0 left-1/2 w-1 h-full bg-gradient-to-b from-transparent via-blue-400/20 to-transparent animate-flow"></div>
          <div className="absolute top-0 right-1/3 w-1 h-full bg-gradient-to-b from-transparent via-purple-400/20 to-transparent animate-flow animation-delay-2000"></div>
        </div>
        
        {/* Overlay gradient for depth */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/50 via-transparent to-purple-900/30"></div>
      </div>

      <div className="relative z-10 flex min-h-screen">
        {/* Left Sidebar */}
        <div className="w-80 p-8 backdrop-blur-md bg-white/5 border-r border-white/10">
          {/* Logo */}
          <div className="mb-12">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Server className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Kiran Garud</h2>
                <p className="text-sm text-gray-300">DevOps Engineer</p>
              </div>
            </div>
          </div>

          {/* Get in Touch */}
          <div className="mb-12">
            <h3 className="text-lg font-semibold mb-6 text-blue-300">Get in Touch</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors">
                <Mail className="w-5 h-5" />
                <span className="text-sm">kiran.garud@email.com</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors">
                <Phone className="w-5 h-5" />
                <span className="text-sm">+1 (555) 123-4567</span>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="mb-12">
            <h3 className="text-lg font-semibold mb-6 text-blue-300">Connect</h3>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/20 transition-all hover:scale-110">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Skills Quick View */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-blue-300">Core Skills</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Cloud className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-gray-300">AWS Solutions Architecture</span>
              </div>
              <div className="flex items-center space-x-2">
                <Server className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-gray-300">Kubernetes & Docker</span>
              </div>
              <div className="flex items-center space-x-2">
                <Cog className="w-4 h-4 text-indigo-400" />
                <span className="text-sm text-gray-300">CI/CD Automation</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Navigation */}
          <nav className="p-8 pb-0">
            <div className="flex items-center justify-between">
              <div className="flex space-x-2">
                <button className="px-6 py-2 bg-blue-500/20 backdrop-blur-sm border border-blue-500/30 rounded-full text-sm font-medium hover:bg-blue-500/30 transition-all">
                  Home
                </button>
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  About
                </button>
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  Skills
                </button>
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  Projects
                </button>
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  Architecture
                </button>
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  Blogs
                </button>
              </div>
              <div className="flex space-x-3">
                <button className="px-6 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-sm font-medium hover:bg-white/10 transition-all">
                  Contact
                </button>
                <button className="px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full text-sm font-medium hover:from-blue-400 hover:to-purple-500 transition-all">
                  Hire Me
                </button>
              </div>
            </div>
          </nav>

          {/* Hero Section */}
          <div className="flex-1 flex items-center justify-between p-8">
            <div className="max-w-2xl">
              <h1 className="text-6xl font-bold mb-6 leading-tight">
                Build. Automate.{' '}
                <span className="bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                  Scale.
                </span>
              </h1>
              <h2 className="text-2xl text-gray-300 mb-4">
                I'm Kiran Garud, a Cloud & DevOps Engineer
              </h2>
              <p className="text-lg text-gray-400 mb-8 leading-relaxed">
                Certified AWS Solutions Architect with real-world experience in Cloud Infrastructure, 
                CI/CD, and Automation. Transforming complex systems into scalable, efficient solutions.
              </p>
              <div className="flex space-x-4">
                <button className="flex items-center space-x-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-medium hover:from-blue-400 hover:to-purple-500 transition-all hover:scale-105">
                  <Download className="w-5 h-5" />
                  <span>Download Resume</span>
                </button>
                <button className="flex items-center space-x-2 px-8 py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full font-medium hover:bg-white/20 transition-all">
                  <span>View Projects</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Right Side Cards */}
            <div className="space-y-6">
              {/* Projects Card */}
              <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold text-blue-300">20+</h3>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
                <p className="text-gray-300 mb-2">Real Projects Deployed</p>
                <p className="text-sm text-gray-400">Production-ready infrastructure solutions across AWS, Azure, and GCP</p>
              </div>

              {/* Certifications Card */}
              <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex space-x-2">
                    <Award className="w-6 h-6 text-yellow-400" />
                    <h3 className="text-xl font-bold">Certifications</h3>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                    <span className="text-sm text-gray-300">AWS Solutions Architect</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <span className="text-sm text-gray-300">Kubernetes Administrator</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-sm text-gray-300">Docker Certified Associate</span>
                  </div>
                </div>
              </div>

              {/* Testimonials Card */}
              <div className="w-80 p-6 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl hover:bg-white/15 transition-all group">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Users className="w-6 h-6 text-green-400" />
                    <h3 className="text-xl font-bold">Live Testimonials</h3>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
                <div className="flex -space-x-2 mb-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full border-2 border-white/20"></div>
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-full border-2 border-white/20"></div>
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full border-2 border-white/20"></div>
                  <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full border-2 border-white/20 flex items-center justify-center">
                    <span className="text-xs font-bold">+5</span>
                  </div>
                </div>
                <p className="text-sm text-gray-300">"Exceptional DevOps skills and AWS expertise. Delivered scalable solutions on time."</p>
              </div>
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="p-8 pt-0">
            <button className="w-full max-w-md mx-auto flex items-center justify-center space-x-3 py-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full hover:bg-white/10 transition-all group">
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              <span className="text-lg">Swipe or Scroll to explore my DevOps journey...</span>
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 text-center text-sm text-gray-400 bg-black/20 backdrop-blur-sm border-t border-white/10">
        <p>&copy; 2025 Kiran Garud. All rights reserved. | Built with React & Tailwind CSS</p>
      </div>
    </div>
  );
}

export default App;